// form.js
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("productForm");
  const nameInput = document.getElementById("productName");
  const priceInput = document.getElementById("productPrice");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const name = nameInput.value.trim();
    const price = parseFloat(priceInput.value);

    if (!name || isNaN(price)) {
      alert("Please enter a valid product name and price.");
      return;
    }

    const res = await fetch("/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, price }),
    });

    const result = await res.json();
    if (res.ok) {
      alert(`Product added: ${result.name}`);
      form.reset();
    } else {
      alert("Error: " + result.error);
    }
  });
});
