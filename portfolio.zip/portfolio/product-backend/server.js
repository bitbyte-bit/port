// server.js
const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./database');

const app = express();
const PORT = 4000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// API to get all products
app.get('/products', (req, res) => {
  db.all('SELECT * FROM products ORDER BY createdAt DESC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// API to submit a new product (form submission)
app.post('/products', (req, res) => {
  const { name, price } = req.body;
  if (!name || isNaN(price)) {
    return res.status(400).json({ error: 'Invalid product data' });
  }

  const stmt = db.prepare('INSERT INTO products (name, price) VALUES (?, ?)');
  stmt.run(name, parseFloat(price), function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.status(201).json({ id: this.lastID, name, price });
  });
});

// Serve index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
