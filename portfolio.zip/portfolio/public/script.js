const root=document.getElementById('app');

const head=document.createElement('header');
head.className='header';
 

const title=document.createElement('h2');
title.innerText='citystore';
title.className='pop-headings';

const menu = document.createElement('span');
menu.className = 'material-icons';
menu.innerText = 'menu';
menu.id='menu';

menu.addEventListener('click', () => {
	const overlay = document.createElement('div');
	overlay.style.position = 'fixed';
	overlay.style.top = '0';
	overlay.style.left = '0';
	overlay.style.width = '100vw';
	overlay.style.height = '100vh';
	overlay.className='overlay';
	overlay.style.zIndex = '999';
	overlay.id = 'menu-overlay';

	const sideMenu = document.createElement('div');
	sideMenu.style.position = 'fixed';
    sideMenu.className='side-menu';
	sideMenu.style.top = '0';
	sideMenu.style.right = '0';
	sideMenu.style.boxShadow = '-2px 0 8px rgba(0,0,0,0.2)';
	sideMenu.style.display = 'flex';
	sideMenu.style.flexDirection = 'column';
	sideMenu.style.transition = 'transform 0.3s ease';
	sideMenu.style.transform = 'translateX(0)';
	sideMenu.id = 'side-menu';

	const menuHeader = document.createElement('h2');
	menuHeader.innerText = 'citystore';
	menuHeader.style.fontSize = '1.5rem';
    menuHeader.className='pop-headings';

    const closeure=document.createElement('span');
    closeure.className='material-icons';
    closeure.innerText='close';
    closeure.style.cursor='pointer';
    closeure.id='closure';

    const headers=document.createElement('p');
    headers.className='side-header';

    headers.appendChild(menuHeader)
    headers.appendChild(closeure)
	sideMenu.appendChild(headers);

	const menuList = [
        'about',
		'services',
		'my profile',
		'sell with us',
		'legit sellers',
		'settings',
		'privacy policy',
		'terms and conditions',
		'need help'
    ];
    menuList.forEach(list => {
        const menuItem=document.createElement('li');
        menuItem.className='lists';
        menuItem.innerText=list; 
     sideMenu.appendChild(menuItem);
	 menuItem.addEventListener('click', () => {
		const newItemsModal = document.querySelector('.default-display');
		if (newItemsModal) {
			newItemsModal.innerHTML = ''; 
			mainTitle.innerText = ``;
			if(list === 'about'){
				overlay.remove()
				mainTitle.innerHTML=`${list}`;
				const aboutContent = document.createElement('div');
				aboutContent.className = 'about-content';

				const aboutText = document.createElement('main');
				aboutText.innerHTML = `
				<marquee behavior='alternate'>Welcome to the CityStore !</marquee>
				 <h3>
				 We offer a wide range of products to cater to your 
				 urban lifestyle
				 </h3>
				 <strong><h3 class='pop-headings'>Background;</h3></strong>
				 With a humble and weak background that was set by 
				 a number of individuals in the august of 2022,as citystore we have managed idealise,innovate and extend our goods and services to our 
				 beloved and esteemed clients in all their regions.
				 <h3 class='pop-headings'>what we do;</h3>
				 As citystore,we offer variety of products such as;<br>
				 <li>
				 <div class='accordion'>
				 <input type='radio' name='accordion' id='accordion1'/>
				 <label for='accordion1'>Accessories</label>
				 <div class='accordion-content'>Citystore offers you variety of modern,pocket and user friendly
				 accessories wherever you are.From different manufacturing companies as required by the client.<br><br>
				 <strong>NOTE:</strong>You are requsted to read carfully the details of a given 
				 item before placing an order</div>
				 </div>
				 </li>
				 <li>
				 <div class='accordion'>
				 <input type='radio' name='accordion' id='accordion2'/>
				 <label for='accordion1'>Gadgets</label>
				 <div class='accordion-content'>Gadgets</div>
				 </div>
				 </li>
				 <li>
				 <div class='accordion'>
				 <input type='radio' name='accordion' id='accordion2'/>
				 <label for='accordion1'>Entertainment</label>
				 <div class='accordion-content'>Gadgets</div>
				 </div>
				 </li>
				 <li>
				 <div class='accordion'>
				 <input type='radio' name='accordion' id='accordion2'/>
				 <label for='accordion1'>Electrical installation</label>
				 <div class='accordion-content'>Gadgets</div>
				 </div>
				 </li>
				 <li>
				 <div class='accordion'>
				 <input type='radio' name='accordion' id='accordion2'/>
				 <label for='accordion1'>Transportation</label>
				 <div class='accordion-content'>Gadgets</div>
				 </div>
				 </li>


				 `;
				aboutContent.appendChild(aboutText);

				newItemsModal.appendChild(aboutContent);
			} else if(list === 'services'){
				overlay.remove()
				mainTitle.innerHTML=`${list}`;
				const servicesContent = document.createElement('div');
				servicesContent.className = 'services-content';

				const servicesText = document.createElement('p');
				servicesText.innerText = 'Our services include product customization, fast shipping, and 24/7 customer support.';
				servicesContent.appendChild(servicesText);
				newItemsModal.appendChild(servicesContent);
			} else if(list === 'my profile'){
				overlay.remove()
				mainTitle.innerHTML=`${list}`;
				const profileContent = document.createElement('div');
				profileContent.className = 'profile-content';

				const profileText = document.createElement('p');
				profileText.innerText = 'Manage your profile settings and preferences.';
				profileContent.appendChild(profileText);

				newItemsModal.appendChild(profileContent);
			} else if(list === 'sell with us'){
				overlay.remove()
				mainTitle.innerHTML=`${list}`;
				const sellContent = document.createElement('div');
				sellContent.className = 'sell-content';

				const sellText = document.createElement('p');
				sellText.innerText = 'Join us as a seller and showcase your products to a wider audience.';
				sellContent.appendChild(sellText);

				newItemsModal.appendChild(sellContent);

			} else if(list === 'settings'){
				overlay.remove()
				mainTitle.innerHTML=`${list}`;
				const settingsContent = document.createElement('div');
				settingsContent.className = 'settings-content';

				const settingsText = document.createElement('p');
				settingsText.innerText = 'Adjust your application settings and preferences.';
				settingsContent.appendChild(settingsText);
				//settings list
				const settingsList=document.createElement('div');
				settingsList.className='settings-list';

				const theme=document.createElement('li');
				theme.className='lines';
				theme.innerText='app theme';
				//theme function
				theme.addEventListener('click',()=>{
					const themes=document.createElement('div');
					themes.className='themes';
					//themes in themes()
					const themeIcons=[
						'light mode',
						'dark mode',
					];
					themeIcons.forEach(themeIcon=>{
						const themeShell=document.createElement('button');
						themeShell.className='theme-shell';
						themeShell.innerText=themeIcon;
						themes.appendChild(themeShell)
						if(themeIcon==='light mode'){
							themeShell.addEventListener('click',()=>{
								document.body.style.backgroundColor='white';
								main.style.color='black';
							});
						}if(themeIcon==='dark mode'){
							themeShell.addEventListener('click',()=>{
								document.body.style.backgroundColor='rgb(12,3,36)';
								main.style.color='white';
							});
						}
					});
					newItemsModal.appendChild(themes)
					try {
					theme.remove()	
					} catch (error) {
					}
				});
				settingsList.appendChild(theme);

				const language=document.createElement('li');
				language.className='lines';
				language.innerText='change language';
				//language function
				language.addEventListener('click',()=>{
					const languages=document.createElement('div');
					languages.className='languages';

					
					newItemsModal.appendChild(languages);
					
				});
				settingsList.appendChild(language);

				const text=document.createElement('li');
				text.className='lines';
				text.innerText='change font size';
				settingsList.appendChild(text);
				
				settingsContent.appendChild(settingsList)
				newItemsModal.appendChild(settingsContent)
				newItemsModal.appendChild(theme)
			}else if(list=== 'legit sellers'){
				overlay.remove()
				mainTitle.innerHTML=`${list}`;
				const legitSellers=document.createElement('div');
				legitSellers.className='legit-sellers';

				const legitSellersText=document.createElement('p');
				legitSellersText.className='legit-sellers-text'
			}else if(list === 'privacy policy'){
				overlay.remove()
				mainTitle.innerHTML=`${list}`;
				const privacyContent = document.createElement('div');
				privacyContent.className = 'privacy-content';

				const privacyText = document.createElement('p');
				privacyText.innerText = 'Your privacy is important to us. Read our privacy policy to learn more.';
				privacyContent.appendChild(privacyText);

				newItemsModal.appendChild(privacyContent);
			} else if(list === 'terms and conditions'){
				overlay.remove()
				mainTitle.innerHTML=`${list}`;
				const termsContent = document.createElement('div');
				termsContent.className = 'terms-content';

				const termsText = document.createElement('p');
				termsText.innerText = 'Please read our terms and conditions before using our services.';
				termsContent.appendChild(termsText);

				newItemsModal.appendChild(termsContent);
			} else if(list === 'need help'){
				overlay.remove()
				mainTitle.innerHTML=`${list}`;
				const helpContent = document.createElement('div');
				helpContent.className = 'help-content';

				const helpText = document.createElement('p');
				helpText.innerText = 'If you need assistance, please contact our support team.';
				helpContent.appendChild(helpText);

				newItemsModal.appendChild(helpContent);
			}
		}
	});
	});
	closeure.addEventListener('click', () => {
	document.body.removeChild(overlay);
		
	});

	document.body.appendChild(overlay);
	overlay.appendChild(sideMenu);
});
head.appendChild(title)
head.appendChild(menu)
root.appendChild(head)


const buttonCase=document.createElement('div');
buttonCase.className='button-case';
const items = [
    'Shoes',
	'Tshirt',
	'Jeans',
	'Jacket',
	'Hat',
    'Bag',
	'Watch',
	'Sunglasses',
	'Belt',
	'Socks'
];
items.forEach(item => {
    const btn = document.createElement('button');
    btn.className = 'shop-item-btn';
    btn.innerText = item;
    buttonCase.appendChild(btn);
	btn.addEventListener('click', () => {
		const newItemsModal = document.querySelector('.default-display');
		if (newItemsModal) {
			newItemsModal.innerHTML = ''; // Clear previous items
			mainTitle.innerText = `Viewing ${item} items`;
			if(btn.innerText === 'Shoes'){
				const shoesList = [
					{ name: 'Nike Air Max', price: '$120', img:'city.png' },
					{ name: 'Adidas Ultraboost', price: '$180', img:'city.png' },
					{ name: 'Puma RS-X', price: '$110', img:'city.png' },
					{ name: 'Reebok Classic', price: '$90', img:'city.png' },
					{ name: 'New Balance 574', price: '$100', img:'city.png' }
				];
				shoesList.forEach(shoe => {
					const itemDiv = document.createElement('div');
					itemDiv.className = 'item';

					const itemName = document.createElement('div');
					itemName.className = 'item-name';
					itemName.innerText = shoe.name;

					const itemPrice = document.createElement('div');
					itemPrice.className = 'item-price';
					itemPrice.innerText = shoe.price;

					const image=document.createElement('img');
					image.className='image-item';
					image.src=shoe.img;

					itemDiv.appendChild(image)
					itemDiv.appendChild(itemName);
					itemDiv.appendChild(itemPrice);
					//buy buttons
					const buyButton = document.createElement('button');
					buyButton.className = 'buy-button';
					buyButton.innerText = 'Buy Now';
					itemDiv.appendChild(buyButton);
					buyButton.addEventListener('click', () => {
						alert(`You have purchased ${shoe.name} for ${shoe.price}`);
					});
					newItemsModal.style.display='flex';
					newItemsModal.style.flexWrap='wrap';
					newItemsModal.appendChild(itemDiv);
				});

			}if(btn.innerText === 'Tshirt'){
				const tshirtList = [
					{ name: 'Graphic Tee', price: '$25', img:'city.png' },
					{ name: 'Plain White Tee', price: '$15', img:'city.png' },
					{ name: 'Vintage Band Tee', price: '$30', img:'city.png' },
					{ name: 'Polo Shirt', price: '$40', img:'city.png' },
					{ name: 'Hooded Tee', price: '$35', img:'city.png' }
				];
				tshirtList.forEach(tshirt => {
					const itemDiv = document.createElement('div');
					itemDiv.className = 'item';

					const itemName = document.createElement('div');
					itemName.className = 'item-name';
					itemName.innerText = tshirt.name;

					const itemPrice = document.createElement('div');
					itemPrice.className = 'item-price';
					itemPrice.innerText = tshirt.price;

					const image=document.createElement('img');
					image.className='image-item';
					image.src=tshirt.img;

					itemDiv.appendChild(image)
					itemDiv.appendChild(itemName);
					itemDiv.appendChild(itemPrice);

					newItemsModal.appendChild(itemDiv);
				});
			}if(btn.innerText === 'Jeans'){
				const jeansList = [
					{ name: 'Slim Fit Jeans', price: '$50', img:'city.png' },
					{ name: 'Bootcut Jeans', price: '$55', img:'city.png' },
					{ name: 'Skinny Jeans', price: '$45', img:'city.png' },
					{ name: 'Relaxed Fit Jeans', price: '$60', img:'city.png' },
					{ name: 'Distressed Jeans', price: '$65', img:'city.png' }
				];
				jeansList.forEach(jean => {
					const itemDiv = document.createElement('div');
					itemDiv.className = 'item';

					const itemName = document.createElement('div');
					itemName.className = 'item-name';
					itemName.innerText = jean.name;

					const itemPrice = document.createElement('div');
					itemPrice.className = 'item-price';
					itemPrice.innerText = jean.price;

					const image=document.createElement('img');
					image.className='image-item';
					image.src=jean.img;

					itemDiv.appendChild(image)
					itemDiv.appendChild(itemName);
					itemDiv.appendChild(itemPrice);

					newItemsModal.appendChild(itemDiv);
				});
			}if(btn.innerText === 'Jacket'){
				const jacketList = [
					{ name: 'Leather Jacket', price: '$120', img:'city.png' },
					{ name: 'Denim Jacket', price: '$80', img:'city.png' },
					{ name: 'Bomber Jacket', price: '$100', img:'city.png' },
					{ name: 'Puffer Jacket', price: '$150', img:'city.png' },
					{ name: 'Windbreaker Jacket', price: '$90', img:'city.png' }
				];
				jacketList.forEach(jacket => {
					const itemDiv = document.createElement('div');
					itemDiv.className = 'item';

					const itemName = document.createElement('div');
					itemName.className = 'item-name';
					itemName.innerText = jacket.name;

					const itemPrice = document.createElement('div');
					itemPrice.className = 'item-price';
					itemPrice.innerText = jacket.price;

					const image=document.createElement('img');
					image.className='image-item';
					image.src=jacket.img;

					itemDiv.appendChild(image)
					itemDiv.appendChild(itemName);
					itemDiv.appendChild(itemPrice);

					newItemsModal.appendChild(itemDiv);
				});
			}if(btn.innerText === 'Hat'){
				const hatList = [
					{ name: 'Baseball Cap', price: '$20', img:'city.png' },
					{ name: 'Beanie', price: '$15', img:'city.png' },
					{ name: 'Sun Hat', price: '$25', img:'city.png' },
					{ name: 'Bucket Hat', price: '$30', img:'city.png' },
					{ name: 'Fedora', price: '$35', img:'city.png' }
				];
				hatList.forEach(hat => {
					const itemDiv = document.createElement('div');
					itemDiv.className = 'item';

					const itemName = document.createElement('div');
					itemName.className = 'item-name';
					itemName.innerText = hat.name;

					const itemPrice = document.createElement('div');
					itemPrice.className = 'item-price';
					itemPrice.innerText = hat.price;

					const image=document.createElement('img');
					image.className='image-item';
					image.src=hat.img;

					itemDiv.appendChild(image)
					itemDiv.appendChild(itemName);
					itemDiv.appendChild(itemPrice);

					newItemsModal.appendChild(itemDiv);
				});
			}if(btn.innerText === 'Bag'){
				const bagList = [
					{ name: 'Backpack', price: '$40', img:'city.png' },
					{ name: 'Messenger Bag', price: '$50', img:'city.png' },
					{ name: 'Tote Bag', price: '$30', img:'city.png' },
					{ name: 'Duffel Bag', price: '$60', img:'city.png' },
					{ name: 'Laptop Bag', price: '$70', img:'city.png' }
				];
				bagList.forEach(bag => {
					const itemDiv = document.createElement('div');
					itemDiv.className = 'item';

					const itemName = document.createElement('div');
					itemName.className = 'item-name';
					itemName.innerText = bag.name;

					const itemPrice = document.createElement('div');
					itemPrice.className = 'item-price';
					itemPrice.innerText = bag.price;

					const image=document.createElement('img');
					image.className='image-item';
					image.src=bag.img;

					itemDiv.appendChild(image)
					itemDiv.appendChild(itemName);
					itemDiv.appendChild(itemPrice);

					newItemsModal.appendChild(itemDiv);
				});
			}if(btn.innerText === 'Watch'){
				const watchList = [
					{ name: 'Analog Watch', price: '$100', img:'city.png' },
					{ name: 'Digital Watch', price: '$80', img:'city.png' },
					{ name: 'Smart Watch', price: '$200', img:'city.png' },
					{ name: 'Leather Strap Watch', price: '$120', img:'city.png' },
					{ name: 'Metal Strap Watch', price: '$150', img:'city.png' }
				];
				watchList.forEach(watch => {
					const itemDiv = document.createElement('div');
					itemDiv.className = 'item';

					const itemName = document.createElement('div');
					itemName.className = 'item-name';
					itemName.innerText = watch.name;

					const itemPrice = document.createElement('div');
					itemPrice.className = 'item-price';
					itemPrice.innerText = watch.price;

					const image=document.createElement('img');
					image.className='image-item';
					image.src=watch.img;

					itemDiv.appendChild(image)
					itemDiv.appendChild(itemName);
					itemDiv.appendChild(itemPrice);

					newItemsModal.appendChild(itemDiv);
				});
			}if(btn.innerText === 'Sunglasses'){
				const sunglassesList = [
					{ name: 'Aviator Sunglasses', price: '$50', img:'city.png' },
					{ name: 'Wayfarer Sunglasses', price: '$60', img:'city.png' },
					{ name: 'Round Sunglasses', price: '$40', img:'city.png' },
					{ name: 'Cat Eye Sunglasses', price: '$70', img:'city.png' },
					{ name: 'Sport Sunglasses', price: '$80', img:'city.png' }
				];
				sunglassesList.forEach(sunglass => {
					const itemDiv = document.createElement('div');
					itemDiv.className = 'item';

					const itemName = document.createElement('div');
					itemName.className = 'item-name';
					itemName.innerText = sunglass.name;

					const itemPrice = document.createElement('div');
					itemPrice.className = 'item-price';
					itemPrice.innerText = sunglass.price;

					const image=document.createElement('img');
					image.className='image-item';
					image.src=sunglass.img;

					itemDiv.appendChild(image)
					itemDiv.appendChild(itemName);
					itemDiv.appendChild(itemPrice);

					newItemsModal.appendChild(itemDiv);
				});
			}if(btn.innerText === 'Belt'){
				const beltList = [
					{ name: 'Leather Belt', price: '$30', img:'city.png' },
					{ name: 'Canvas Belt', price: '$20', img:'city.png' },
					{ name: 'Woven Belt', price: '$25', img:'city.png' },
					{ name: 'Dress Belt', price: '$40', img:'city.png' },
					{ name: 'Casual Belt', price: '$35', img:'city.png' }
				];
				beltList.forEach(belt => {
					const itemDiv = document.createElement('div');
					itemDiv.className = 'item';

					const itemName = document.createElement('div');
					itemName.className = 'item-name';
					itemName.innerText = belt.name;

					const itemPrice = document.createElement('div');
					itemPrice.className = 'item-price';
					itemPrice.innerText = belt.price;

					const image=document.createElement('img');
					image.className='image-item';
					image.src=belt.img;

					itemDiv.appendChild(image)
					itemDiv.appendChild(itemName);
					itemDiv.appendChild(itemPrice);

					newItemsModal.appendChild(itemDiv);
				});
			}if(btn.innerText === 'Socks'){
				const socksList = [
					{ name: 'Cotton Socks', price: '$10', img:'city.png' },
					{ name: 'Wool Socks', price: '$15', img:'city.png' },
					{ name: 'Sports Socks', price: '$12', img:'city.png' },
					{ name: 'Dress Socks', price: '$18', img:'city.png' },
					{ name: 'Ankle Socks', price: '$8', img:'city.png' }
				];
				socksList.forEach(sock => {
					const itemDiv = document.createElement('div');
					itemDiv.className = 'item';

					const itemName = document.createElement('div');
					itemName.className = 'item-name';
					itemName.innerText = sock.name;

					const itemPrice = document.createElement('div');
					itemPrice.className = 'item-price';
					itemPrice.innerText = sock.price;

					const image=document.createElement('img');
					image.className='image-item';
					image.src=sock.img;

					itemDiv.appendChild(image)
					itemDiv.appendChild(itemName);
					itemDiv.appendChild(itemPrice);

					newItemsModal.appendChild(itemDiv);
				});
			}
		}
	});
});
root.appendChild(buttonCase)


const main=document.createElement('fieldset');
main.className='main';
const mainTitle=document.createElement('legend');
mainTitle.className='main-title';
mainTitle.innerText='';
main.appendChild(mainTitle)
//display field


//default display
const newItemsModal=document.createElement('div');
newItemsModal.className='default-display';

const searchBox=document.createElement('input');
searchBox.type='search';
searchBox.placeholder='search in new items'
searchBox.className='inputs';
searchBox.id='searchBox';
searchBox.addEventListener('input', (e) => {
	const searchTerm = e.target.value.toLowerCase();
	const items = newItemsModal.querySelectorAll('.item');
	items.forEach(item => {
		const itemName = item.querySelector('.item-name').innerText.toLowerCase();
		if (itemName.includes(searchTerm)) {
			item.style.display = 'block';
		} else {
			item.style.display = 'none';
		}

	});
});

main.appendChild(searchBox)

	const newItemBox=document.createElement('div');
	newItemBox.className='new-items';
const itemsList = [
	{ name: 'Nike Air Max', price: '$120', img:'city.png' },
	{ name: 'Adidas Ultraboost', price: '$180', img:'city.png' },
	{ name: 'Puma RS-X', price: '$110', img:'city.png' },
	{ name: 'Reebok Classic', price: '$90', img:'city.png' },
	{ name: 'New Balance 574', price: '$100', img:'city.png' },
	{ name: 'Converse Chuck Taylor', price: '$65', img:'city.png' },
	{ name: 'Vans Old Skool', price: '$70', img:'city.png' },
	{ name: 'Asics Gel-Kayano', price: '$160', img:'city.png' },
	{ name: 'Under Armour HOVR', price: '$140', img:'city.png' },
	{ name: 'Hoka One One Bondi', price: '$150', img:'city.png' },
	{ name: 'Saucony Triumph', price: '$130', img:'city.png' },
	{ name: 'Brooks Ghost', price: '$120', img:'city.png' },
	{ name: 'Mizuno Wave Rider', price: '$110', img:'city.png' },
	{ name: 'Fila Disruptor', price: '$80', img:'city.png' },
	{ name: 'K-Swiss Classic', price: '$75', img:'city.png' }
];
itemsList.forEach(item => {
	const itemDiv = document.createElement('div');
	itemDiv.className = 'item';

	const itemName = document.createElement('div');
	itemName.className = 'item-name';
	itemName.innerText = item.name;

	const itemPrice = document.createElement('div');
	itemPrice.className = 'item-price';
	itemPrice.innerText = item.price;

	const imgage=document.createElement('img');
	imgage.className='image-item';
	imgage.src=item.img;

	itemDiv.appendChild(imgage)
	itemDiv.appendChild(itemName);
	itemDiv.appendChild(itemPrice);


	//buy buttons
	const itemBtns=document.createElement('div');
	itemBtns.className='item-btns';

	const buyBtn=document.createElement('button');
	buyBtn.className='buy-btn';
	buyBtn.innerText='buy';
	
	const cartBtn=document.createElement('button');
	cartBtn.className='cart-btn';
	cartBtn.innerText='add to cart';
	itemBtns.appendChild(buyBtn)
	itemBtns.appendChild(cartBtn)
	itemDiv.appendChild(itemBtns)

	buyBtn.addEventListener('click',()=>{

	})




	newItemBox.appendChild(itemDiv);
	newItemsModal.appendChild(newItemBox)});
	
main.appendChild(newItemsModal)
//number of new itms in stock

const newItemsCount = document.createElement('div');
newItemsCount.className = 'new-items-count';
newItemsCount.innerText = `${itemsList.length}`;

if(main.appendChild(newItemsModal)){
	mainTitle.innerHTML=` ${newItemsCount.innerText} new items in stock`;
}else{
	mainTitle.innerText='';
}
root.appendChild(main)

//bottom navigation
const foot=document.getElementById('footer');
foot.className='footer';

const homeBtn=document.createElement('span');
homeBtn.className='material-icons';
homeBtn.innerText='home';
homeBtn.id='homeBtn';

const hotDealsBtn=document.createElement('span');
hotDealsBtn.className='material-icons';
hotDealsBtn.innerText='local_offer';
hotDealsBtn.id='hotDealsBtn';

const cartBtn=document.createElement('span');
cartBtn.className='material-icons';
cartBtn.innerText='shopping_cart';
cartBtn.id='cartBtn';

const profileBtn=document.createElement('span');
profileBtn.className='material-icons';
profileBtn.innerText='person';
profileBtn.id='profileBtn';

const homeBtnHandler = () => {
	const newItemsModal = document.querySelector('.default-display');
	newItemsModal.innerHTML='';
	newItemsModal.appendChild(newItemBox);
	mainTitle.innerText = 'Viewing New Items';
};
homeBtn.addEventListener('click', homeBtnHandler);
hotDealsBtn.addEventListener('click', () => {
	const newItemsModal = document.querySelector('.default-display');
	newItemsModal.innerHTML = '';
	mainTitle.innerText = 'Viewing Hot Deals';
});

cartBtn.addEventListener('click', () => {
	const newItemsModal = document.querySelector('.default-display');
	newItemsModal.innerHTML = '';
	mainTitle.innerText = 'Viewing Cart';
	const cartFlag=document.createElement('div');
	cartFlag.className='cart-flag';



});

foot.appendChild(homeBtn);
foot.appendChild(hotDealsBtn);
foot.appendChild(cartBtn);
foot.appendChild(profileBtn);
root.appendChild(foot);


profileBtn.addEventListener('click', () => {
	const profileModal = document.createElement('div');
	profileModal.className = 'profile-modal';

	const profileTitle = document.createElement('h2');
	profileTitle.className = 'pop-headings';
	profileTitle.innerText='my profile';

	const profilePicture=document.createElement('input');
	profilePicture.type='image';
	profilePicture.accept='image/*';
	profilePicture.alt='photo'
	profilePicture.className='profile-picture';


	const name = document.createElement('input');
	name.className = 'inputs';
	name.placeholder='full names';
	name.contentEditable=false;
	name.id='UserName';

	const email = document.createElement('input');
	email.className = 'inputs';
	email.placeholder = 'email';
	email.contentEditable = false;
	email.id = 'UserEmail';
	
	const UserPhone=document.createElement('p');
	UserPhone.className='inputs';
	UserPhone.id='UserPhone';
	UserPhone.style.textAlign='left';
	UserPhone.innerText='add phone number';
	UserPhone.contentEditable=true;

	const UserBio=document.createElement('p');
	UserBio.className='inputs';
	UserBio.style.textAlign='left';
	UserBio.contentEditable=true;
	UserBio.innerText='Atukwasa Umar (dev-plaxa technologies) and umar-technologies \n\nhttps://umar-techs.com';
	UserBio.id='UserBio';

	const saveChanges=document.createElement('button');
	saveChanges.className='save-changes';
	saveChanges.innerText='save changes';
	//append profile elements to the profile modal
	profileModal.appendChild(profileTitle)
	profileModal.appendChild(profilePicture)
	profileModal.appendChild(name)
	profileModal.appendChild(email)
	profileModal.appendChild(UserPhone)
	profileModal.appendChild(UserBio)
	profileModal.appendChild(saveChanges)

	const overlay=document.createElement('div');
	overlay.className='overlay';
	//append profile page to the usser interface
	document.body.appendChild(overlay)
	document.body.appendChild(profileModal)
	overlay.addEventListener('click',()=>{
		overlay.remove()
		profileModal.remove()
	});
});

